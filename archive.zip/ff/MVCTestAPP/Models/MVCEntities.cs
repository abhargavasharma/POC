﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVCTestAPP.Models
{
    public class MVCEntities
    {
        public List<User> Users; 
    }
}
