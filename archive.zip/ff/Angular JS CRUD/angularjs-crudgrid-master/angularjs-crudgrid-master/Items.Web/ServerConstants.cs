﻿namespace Items.Web
{
    public static class ServerConstants
    {
        public const string UpdateError = "Error updating item.";
        public const string DeleteError = "Error deleting item.";
        
    }
}