﻿/// <autosync enabled="true" />
/// <reference path="jquery.validate.unobtrusive.js" />
/// <reference path="jquery-1.9.1.js" />
/// <reference path="bootstrap.min.js" />
/// <reference path="jquery.validate.js" />
/// <reference path="respond.min.js" />
/// <reference path="respond.matchmedia.addlistener.min.js" />
/// <reference path="custom/product.js" />
