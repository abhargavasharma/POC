﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MarketEngineProductBAL;
using MarketEngineProductRepository;
using AutoMapper;

namespace MarketEngineProductMaintenance.App_Start
{
    public class AutoMapperConfig
    {
        public static void RegisterMappings()
        {
       

        }
    }
}