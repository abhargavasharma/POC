﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AGLDeveloperTest.Models
{
    public class ResultData
    {
        public string gender { get; set; }
        public List<string> cats { get; set; }

    }
}